from __future__ import annotations

from typing import Any

import time

def run_command(**kwargs: Any) -> Any:
    a = kwargs.get("a", 0)
    b = kwargs.get("b", 0)

    return a + b


def run_time_now() -> Any:
    return f"{time.time_ns()}"


command = {
    "private-a": {
        "value": run_command
    }
}

macros = {
    "static": {
        "file": {
            "targets": {
                "private-a": {
                    "value": "private | ${{ private-time-now }} | ${{ private-time-now }}"
                },
                "private-b": {
                    "value": "private-a | ${{ private-a }}"
                }
            }
        }
    },
    "dynamic": {
        "targets": {
            "private-time-now": {
                "value": run_time_now
            }
        }
    }
}

