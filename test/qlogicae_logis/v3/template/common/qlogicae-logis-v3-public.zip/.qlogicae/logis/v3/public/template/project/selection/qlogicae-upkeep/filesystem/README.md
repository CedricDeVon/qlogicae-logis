</br>

<div style="width: 100%; display: flex; justify-content: center;">
    <image alt="the ${{ main-company-base-name }} logo" src="${{ main-company-base-logo-filesystem-path }}" width="256px">
</div>

</br>


<div style="text-align: center;">
  <h1>${{ qlogicae-upkeep-display-brand-name }}</h1>
  <p style="font-style: italic;">${{ qlogicae-upkeep-base-description }}</p>
<div style="margin: 32px 64px;">

![Version](https://img.shields.io/badge/Version-${{ qlogicae-upkeep-current-version-label }}-blue)
![License: MIT](https://img.shields.io/badge/License-MIT-red)
![Google](https://img.shields.io/badge/Google-Sheets-green)
![Looker](https://img.shields.io/badge/Looker-Studio-blue)

  </div>
</div>

</br>



<h2>About</h2>

<p>Strong logistics often win wars, at the very least. This project exists to help me win mine: budgeting. I wanted a tool to help me manage my finances, track them as well as I can, and visualize them beautifully.</p>

<p>While more sophisticated data tools like Microsoft's Power BI exist, using the most advanced options is not my focus right now. I simply want to start budgeting soon rather than later.</p>

<p>Better solutions will come when the time is right. For now, at least, I have made a start.</p>

</br>



<h2>Links</h2>

<p>Click to use the application - straight to the point.</p>

${{ qlogicae-upkeep-looker-studio-link }}

</br>
